# [please implement your unit test for testing raising exception.]
